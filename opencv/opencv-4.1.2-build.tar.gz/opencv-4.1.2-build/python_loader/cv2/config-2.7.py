PYTHON_EXTENSIONS_PATHS = [
    '/home/pi/Downloads/opencv-4.1.2-build/lib/'
] + PYTHON_EXTENSIONS_PATHS
