PYTHON_EXTENSIONS_PATHS = [
    '/home/pi/Downloads/opencv-4.1.2-build/lib/python3'
] + PYTHON_EXTENSIONS_PATHS
