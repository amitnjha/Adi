
#define OPENCV_INSTALL_PREFIX "/usr/local"

#define OPENCV_TEST_DATA_INSTALL_PATH "share/opencv4/testdata"
