
#define OPENCV_INSTALL_PREFIX "/usr/local"

#define OPENCV_DATA_INSTALL_PATH "share/opencv4"

#define OPENCV_BUILD_DIR "/home/pi/Downloads/opencv-4.1.2-build"

#define OPENCV_DATA_BUILD_DIR_SEARCH_PATHS \
    "../opencv-4.1.2/"

#define OPENCV_INSTALL_DATA_DIR_RELATIVE "../share/opencv4"
