// OpenCV CPU baseline features

#define CV_CPU_BASELINE_FEATURES 0 \


// OpenCV supported CPU dispatched features



#define CV_CPU_DISPATCH_FEATURES 0 \

