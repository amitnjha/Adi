#define CV_CPU_SIMD_FILENAME "/home/pi/Downloads/opencv-4.1.2/modules/core/src/stat.simd.hpp"
#define CV_CPU_DISPATCH_MODES_ALL BASELINE

#undef CV_CPU_SIMD_FILENAME
